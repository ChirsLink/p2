
Run0: All simple cases (except 8th)

Run1: Small file. Checking the case in which all cargo cars are removed one by one from a departing train.

Run0And1:
	- reading from multiple files

Run2: 
	- wrong input command
	- case 8: different cases

Run3:
	- Case insensitivity of destination city and cargo name
	- Non-existing destination city and cargo names as input in all possible cases

Run4: 
	- reading large file

Run_err: 
	- reading noisy file.
	- departing all trains one by one.
